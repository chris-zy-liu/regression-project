See milestone2_final/README.md for instructions. Run commands from this archive root.
